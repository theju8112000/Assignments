#single inheritance in python
# parent class
class Person( object ):    
  
        # __init__ is known as the constructor         
        def __init__(self, name, id):   
                self.name = name
                self.id = id
        def display(self):
                print(self.name)
                print(self.id)
  
# child class
class Employee( Person ):           
        def __init__(self, name, id, salary):
                self.salary = salary  
                # invoking the __init__ of the parent class 
                Person.__init__(self, name, id) 
  
                  
# creation of an object variable or an instance
a = Employee('Rahul', 886012, 200000)    
  
# calling a function of the class Person using its instance
a.display() 