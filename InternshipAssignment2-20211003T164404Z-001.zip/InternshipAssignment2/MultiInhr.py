#Multi level inheritance in python

class Person( object ):    
  
        # __init__ is known as the constructor         
        def __init__(self, name, id):   
                self.name = name
                self.id = id
        def display(self):
                print(self.name)
                print(self.id)
  
class Emply1( Person ):           
        def __init__(self, name, id, salary):
                self.salary = salary  
                # invoking the __init__ of the parent class (Person) 
                Person.__init__(self, name, id) 

class Emply2( Emply1 ):
        def __init__(self, name, id, salary,post):
                self.post=post 
                # invoking the __init__ of the parent class (Emply1)
                Person.__init__(self, name, id,salary)

class Emply2(Emply1):
    def __init__(self, name, id, salary,post,place):
                self.place=place
                # invoking the __init__ of the parent class (Emply2)
                Person.__init__(self, name, id,salary,post)

  
                  
# creation of an object variable or an instance
a = Emply2('Rahul', 886012, 200000,"intern","shimoga")    
  
# calling a function of the class Person using its instance
a.display() 