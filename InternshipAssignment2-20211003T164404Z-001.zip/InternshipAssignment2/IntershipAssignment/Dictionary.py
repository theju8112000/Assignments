fruits={1:"apple",2:"banana",3:"mango",4:"cherry"}
fruits.values()
fruits.update({5:"chickoo"})
fruits.popitem()
x=fruits.keys()
y=fruits.items()
z=fruits.get(2)
print(x)
print(y)
print(z)
print(fruits)
h=fruits.clear()
print(h)

