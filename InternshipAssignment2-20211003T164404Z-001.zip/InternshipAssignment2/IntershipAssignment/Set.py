team={2,3,5,4,6,8,5}
team.add(45)
print(team)
x=team.copy()
print(x)
team.clear()
print(team)


s={"apple","banana","cherry","watermelon"}
o={"google","idle"}
z=s.difference(o)
o.difference_update(o)
print(z)
print(o)

b={"pulav","chapati","roti"}
c={"pi","go","roti"}
g=b.intersection(c)
print(g)

q={1,2,5}
w={5,4,8,6,2,3,1}
e=q.issubset(w)
s=w.issuperset(q)
print(e)
print(s)
