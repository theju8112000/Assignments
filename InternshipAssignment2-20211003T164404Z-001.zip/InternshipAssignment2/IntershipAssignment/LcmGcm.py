def ToFindLCM(x, y): 
    if x < y:  # to find the maximum number among two numbers
        max = y 
    else: 	
        max = x 
    while(True): # infinite loop
        if((max % x == 0) and (max % y == 0)): # remainder of both number is 0
            lcm=max
            break
        max+=1
    return lcm
def ToFindGCD(x, y): 
    if x > y:  # to find the small number among two numbers
        small = y 
    else: 
        small = x 
    for i in range(1, small+1): # looping from 1 to small number
        if((x % i == 0) and (y % i == 0)): # remainder of both number is 0
            gcd = i 
    return gcd 
num1 =int(input("Enter the First number "))
num2= int(input("Enter the Second number "))
print(ToFindLCM(num1,num2))
print (ToFindGCD(num1,num2))
