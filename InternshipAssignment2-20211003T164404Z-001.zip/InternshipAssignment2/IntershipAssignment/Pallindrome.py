# Program to check whether the input integer is  palindrome or not
num=int(input("Enter the number "))
temp=num
res=0	
while(num>0): 
    n=num%10
    res=(res*10)+n
    num=num//10
if(temp==res): # check if input and reverse value is same
    print("Palindrome")
else:
    print("Not palindrome")
