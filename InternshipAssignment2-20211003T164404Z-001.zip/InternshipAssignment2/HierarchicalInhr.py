#Hierarchical Inheritance in python
# parent class
class Person( object ):    
  
        # __init__ is known as the constructor         
        def __init__(self, name, id):   
                self.name = name
                self.id = id
        def display(self):
                print(self.name)
                print(self.id)
  
# child class
class Employee1( Person ):           
        def __init__(self, name, id, salary):
                self.salary = salary  
                # invoking the __init__ of the parent class 
                Person.__init__(self, name, id) 
  
class Employee2( Person ):           
        def __init__(self, name, id, post):
                self.post = post 
                # invoking the __init__ of the parent class 
                Person.__init__(self, name, id,post) 
  
                  
# creation of an object variable or an instance
a = Employee1('Rahul', 886012, 200000)
b = Employee2('Raju',123456,"intern")   
  
# calling a function of the class Person using its instance
a.display() 